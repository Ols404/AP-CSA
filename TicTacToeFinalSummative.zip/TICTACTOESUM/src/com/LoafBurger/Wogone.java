package com.LoafBurger;

import java.awt.*;

import javax.swing.*;
import java.awt.event.*;
@SuppressWarnings("serial")
//Tic-Tac-Toe: Two-player Graphics version with Simple-OO */
public class Wogone extends JFrame{

    public static final int ROWS = 3;//Setting constants for the board
    public static final int COLS = 3;

    //Named-constants of the various dimensions used for graphics drawing*/
    public static final int Cell_Size = 100;                           //Cell width and height (square)
    public static final int Surface_WIDTH = Cell_Size * COLS;          //Paint Surface
    public static final int Surface_HEIGHT = Cell_Size * ROWS;
    public static final int GRID_WIDTH = 8;                            //Grid-line's width
    public static final int GRID_WIDHT_HALF = GRID_WIDTH / 2;          //Grid-line's half-width
    //Symbols (cross/nought) are displayed inside a Cell, with padding from border*/
    public static final int Cell_Padding = Cell_Size / 6;
    public static final int SYMBOL_Size = Cell_Size - Cell_Padding * 2; //Width and Height
    public static final int SYMBOL_STROKE_WIDTH = 8; //pen's stroke width

    /**Use an enumeration (inner class) to represent the various states of the game*/
    public enum GameState {
        InGame, DRAW, CROSS_WON, NOUGHT_WON
    }

    private GameState currentState;  //the current game state

    /**Use an enumeration (inner class) to represent the seeds and Cell contents*/
    public enum Seed {
        Empty, CROSS, NOUGHT
    }

    private Seed currentPlayer;  //the current player
    private Seed[][] board   ; //Game board of ROWS-by-COLS Cells
    private DrawSurface surface; //Drawing surface (JPanel) for the game board
    private JLabel statusBar;  //Status Bar

    // Constructor to setup the game and the GUI components */
    public Wogone() {
        surface = new DrawSurface();  //Construct a drawing surface (a JPanel)
        surface.setPreferredSize(new Dimension(Surface_WIDTH, Surface_HEIGHT));

        //The surface (JPanel) fires a MouseEvent upon mouse-click*/
        surface.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseClicked(MouseEvent e) {  //mouse-clicked handler
                int mouseX = e.getX();
                int mouseY = e.getY();
                //Get the row and column clicked
                int rowSelected = mouseY / Cell_Size;
                int colSelected = mouseX / Cell_Size;

                if (currentState == GameState.InGame) {
                    if (rowSelected >= 0 && rowSelected < ROWS && colSelected >= 0
                            && colSelected < COLS && board[rowSelected][colSelected] == Seed.Empty) {
                        board[rowSelected][colSelected] = currentPlayer; //Make a move
                        updateGame(currentPlayer, rowSelected, colSelected); //update state
                        currentPlayer = (currentPlayer == Seed.CROSS) ? Seed.NOUGHT : Seed.CROSS; //Rotate Player
                    }
                } else {       //Gameover
                    initGame(); //Game Reset
                }
                //Reset Painting
                repaint();  //Call-back PComp
            }
        });

        //StatusBar Setup/Display
        statusBar = new JLabel("  ");
        statusBar.setFont(new Font(Font.DIALOG_INPUT, Font.BOLD, 15));
        statusBar.setBorder(BorderFactory.createEmptyBorder(2, 5, 4, 5));
        Container cp = getContentPane();
        cp.setLayout(new BorderLayout());
        cp.add(surface, BorderLayout.CENTER);
        cp.add(statusBar, BorderLayout.PAGE_END);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();//pack all the components in this J-Frame
        setTitle("Tic Tac Toe");
        setVisible(true);//show this J-Frame
        board = new Seed[ROWS][COLS];//allocate array
        initGame();//initialize the game board contents and game variables
    }

    //Initialize Board Game*/
    public void initGame() {
        for (int row = 0; row < ROWS; ++row) {
            for (int col = 0; col < COLS; ++col) {
                board[row][col] = Seed.Empty; //all Cells empty
            }
        }
        currentState = GameState.InGame; //ready to play
        currentPlayer = Seed.CROSS;       //cross plays first
    }


    public void updateGame(Seed thySeed, int rowSelected, int colSelected) {
        if (hasWon(thySeed, rowSelected, colSelected)) {  //check for win
            currentState = (thySeed == Seed.CROSS) ? GameState.CROSS_WON : GameState.NOUGHT_WON;
        } else if (isDraw()) {  //check for draw
            currentState = GameState.DRAW;
        }
        //Otherwise, no change to current state (still GameState.InGame).
    }


    public boolean isDraw() {
        for (int row = 0; row < ROWS; ++row) {
            for (int col = 0; col < COLS; ++col) {
                if (board[row][col] == Seed.Empty) {
                    return false; //emptyCell found, not draw, exit
                }
            }
        }
        return true;  //No emptyCell(DRAW)
    }


    public boolean hasWon(Seed thySeed, int rowSelected, int colSelected) {
        return (board[rowSelected][0] == thySeed  //3Row
                && board[rowSelected][1] == thySeed
                && board[rowSelected][2] == thySeed
                || board[0][colSelected] == thySeed      //3Column
                && board[1][colSelected] == thySeed
                && board[2][colSelected] == thySeed
                || rowSelected == colSelected            //3Diagonal
                && board[0][0] == thySeed
                && board[1][1] == thySeed
                && board[2][2] == thySeed
                || rowSelected + colSelected == 2        //3Diagonal(Reverse)
                && board[0][2] == thySeed
                && board[1][1] == thySeed
                && board[2][0] == thySeed);
    }


    class DrawSurface extends JPanel {
        @Override
        public void paintComponent(Graphics g) {  //invoke via repaint()
            super.paintComponent(g);    //fill background
            setBackground(Color.WHITE); //set its background color

            //Draw the grid-lines
            g.setColor(Color.LIGHT_GRAY);
            for (int row = 1; row < ROWS; ++row) {
                g.fillRoundRect(0, Cell_Size * row - GRID_WIDHT_HALF,
                        Surface_WIDTH-1, GRID_WIDTH, GRID_WIDTH, GRID_WIDTH);
            }
            for (int col = 1; col < COLS; ++col) {
                g.fillRoundRect(Cell_Size * col - GRID_WIDHT_HALF, 0,
                        GRID_WIDTH, Surface_HEIGHT-1, GRID_WIDTH, GRID_WIDTH);
            }

            //Draw the Seeds of all the Cells if they are not empty
            //Use Graphics2D which allows us to set the pen's stroke
            Graphics2D g2d = (Graphics2D)g;
            g2d.setStroke(new BasicStroke(SYMBOL_STROKE_WIDTH, BasicStroke.CAP_ROUND,
                    BasicStroke.JOIN_ROUND));  //Graphics2D only
            for (int row = 0; row < ROWS; ++row) {
                for (int col = 0; col < COLS; ++col) {
                    int x1 = col * Cell_Size + Cell_Padding;
                    int y1 = row * Cell_Size + Cell_Padding;
                    if (board[row][col] == Seed.CROSS) {
                        g2d.setColor(Color.GREEN);
                        int x2 = (col + 1) * Cell_Size - Cell_Padding;
                        int y2 = (row + 1) * Cell_Size - Cell_Padding;
                        g2d.drawLine(x1, y1, x2, y2);
                        g2d.drawLine(x2, y1, x1, y2);
                    } else if (board[row][col] == Seed.NOUGHT) {
                        g2d.setColor(Color.ORANGE);
                        g2d.drawOval(x1, y1, SYMBOL_Size, SYMBOL_Size);
                    }
                }
            }

            //Prints Status Bar
            if (currentState == GameState.InGame) {
                statusBar.setForeground(Color.BLACK);
                if (currentPlayer == Seed.CROSS) {
                    statusBar.setText("X's Turn");
                } else {
                    statusBar.setText("O's Turn");
                }
            } else if (currentState == GameState.DRAW) {
                statusBar.setForeground(Color.GREEN);
                statusBar.setText("It's a Draw! Click to play again.");
            } else if (currentState == GameState.CROSS_WON) {
                statusBar.setForeground(Color.GREEN);
                statusBar.setText("'X' Won! Click to play again.");
            } else if (currentState == GameState.NOUGHT_WON) {
                statusBar.setForeground(Color.GREEN);
                statusBar.setText("'O' Won! Click to play again.");
            }
        }
    }

    //Main Method(entry)*/
    public static void main(String[] args) {
        //For Safety(GUI Codes)
        SwingUtilities.invokeLater(new Runnable() {

                                       @Override
                                       public void run() {
                                           new Wogone(); //Let Constructor do its thing
                                       }
                                   }
        );
    }
}

//
