package com.LoafBurger;

import java.util.*;

public class Main {

    //These are the arraylist that keep track of all the positions in the game
    static ArrayList<Integer> playerPositions = new ArrayList<Integer>();
    static ArrayList<Integer> computerPositions = new ArrayList<Integer>();

    public static void main(String[] args) {

        Scanner scanner  = new Scanner(System.in);

        System.out.println("Do you want to play with the computer or with a friend");

        String playerAnswer = scanner.nextLine();
        
        if(playerAnswer.equalsIgnoreCase("computer")){

        } else if(playerAnswer.equalsIgnoreCase("friend")){
           new Wogone();
        }


        char [][] gameBoardVisual = {{' ', '|', ' ', '|', ' '},
                {'-', '+', '-', '+', '-'},
                {' ', '|', ' ', '|', ' '},
                {'-', '+', '-', '+', '-'},
                {' ', '|', ' ', '|', ' '}};


        printgameBoardVisual(gameBoardVisual);


        while(true){
            System.out.println("Enter your placement (1-9)");
            int playerPos = scanner.nextInt();

            while(playerPositions.contains(playerPos) || computerPositions.contains(playerPositions)){
                System.out.println("position is taken, enter a correct position");
                playerPos = scanner.nextInt();
            }

            placeSymbol(gameBoardVisual, playerPos, "player");

            Random rand = new Random();
            int cpuPos = rand.nextInt(9) + 1;
            while(playerPositions.contains(cpuPos) || computerPositions.contains(cpuPos)){
                cpuPos = rand.nextInt(9) + 1;
            }
            placeSymbol(gameBoardVisual, cpuPos, "cpu");

            printgameBoardVisual(gameBoardVisual);

           String result =  checkWinnerConditions();
            System.out.println(result);
        }

    }

    public static void printgameBoardVisual(char[][] gameBoardVisual){
        for(char[] row: gameBoardVisual){
            for(char c: row){
                System.out.print(c);
            }
            System.out.println();
        }
    }

    public static void placeSymbol(char[][] gameBoardVisual, int pos, String user){

        char symbol = ' ';

        if(user.equalsIgnoreCase("player")){
            symbol = 'X';
            playerPositions.add((pos));
        } else if(user.equalsIgnoreCase("cpu")){
            symbol = 'O';
            computerPositions.add(pos);
        }

        switch(pos){
            case 1:
                gameBoardVisual[0][0] = symbol;
                break;
            case 2:
                gameBoardVisual[0][2] = symbol;
                break;
            case 3:
                gameBoardVisual[0][4] = symbol;
                break;
            case 4:
                gameBoardVisual[2][0] = symbol;
                break;
            case 5:
                gameBoardVisual[2][2] = symbol;
                break;
            case 6:
                gameBoardVisual[2][4] = symbol;
                break;
            case 7:
                gameBoardVisual[4][0] = symbol;
                break;
            case 8:
                gameBoardVisual[4][2] = symbol;
                break;
            case 9:
                gameBoardVisual[4][4] = symbol;
                break;
            default:
                break;
        }
    }

    public static String checkWinnerConditions(){

        List topRow = Arrays.asList(1, 2, 3);
        List midRow = Arrays.asList(4, 5, 6);
        List bottomRow = Arrays.asList(7, 8, 9);

        List leftCol = Arrays.asList(1, 4, 7);
        List midCol= Arrays.asList(2, 5, 8);
        List rightCol = Arrays.asList(3, 6, 9);

        List cross1= Arrays.asList(1, 5, 9);
        List cross2 = Arrays.asList(7, 5, 3);

        List<List> winning = new ArrayList<List>();


        winning.add(topRow);
        winning.add(midRow);
        winning.add(bottomRow);
        winning.add(leftCol);
        winning.add(midCol);
        winning.add(rightCol);
        winning.add(cross1);
        winning.add(cross2);

        for(List l: winning){
            if(playerPositions.containsAll(l)){
                return "Congrats! You win!";
            } else if(computerPositions.containsAll(l)){
                return "CPU wins! GG Noob";
            } else if(playerPositions.size() + computerPositions.size() == 9){
                return "Tie xD";
            }
        }



        return "";
    }

}
